package com.denchy.serverrack.registry;

import com.denchy.serverrack.ModId;
import com.denchy.serverrack.block.ServerRackBlock;
import net.minecraft.block.AbstractBlock;
import net.minecraft.block.Block;
import net.minecraft.block.MapColor;
import net.minecraft.block.piston.PistonBehavior;
import net.minecraft.registry.Registries;
import net.minecraft.registry.Registry;
import net.minecraft.sound.BlockSoundGroup;
import net.minecraft.util.Identifier;

import java.util.ArrayList;
import java.util.List;

public final class ModBlocks {
    private ModBlocks() {}

    public static final List<Block> RACKS = new ArrayList<>();

    // Three visual variants. All share the multiblock logic (2 tall).
    public static final ServerRackBlock RACK_BASIC = registerRack("server_rack_basic");
    public static final ServerRackBlock RACK_ADVANCED = registerRack("server_rack_advanced");
    public static final ServerRackBlock RACK_MAINFRAME = registerRack("server_rack_mainframe");

    private static ServerRackBlock registerRack(String name) {
        AbstractBlock.Settings settings = AbstractBlock.Settings.create()
                .mapColor(MapColor.BLACK)
                .strength(4.0f, 6.0f)
                .requiresTool()
                .sounds(BlockSoundGroup.METAL)
                .nonOpaque()
                .pistonBehavior(PistonBehavior.BLOCK)
                .luminance(state -> 6);
        ServerRackBlock block = new ServerRackBlock(settings);
        Identifier id = ModId.of(name);
        Registry.register(Registries.BLOCK, id, block);
        RACKS.add(block);
        return block;
    }

    public static void register() {
        // triggers static init
    }
}
